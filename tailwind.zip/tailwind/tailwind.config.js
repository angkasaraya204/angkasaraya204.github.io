/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./view/**/*.{html,js}'],
  theme: {
    extend: {},
  },
  plugins: [],
  darkMode: 'class',
}
